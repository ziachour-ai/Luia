package com.arscreenanchor.display

import android.hardware.usb.*
import java.util.zip.CRC32
import kotlin.math.*

/**
 * Lecture de l'IMU des XREAL Air / Air 2 / Air 2 Pro (interface USB 3, endpoints 0x84 / 0x05).
 * Protocole reconstitué par la communauté (ar-drivers-rs, voidcomputing.hu) : NON officiel.
 */
class XrealImu(private val conn: UsbDeviceConnection, private val dev: UsbDevice) {
    @Volatile var rate = 0
    @Volatile var info = "démarrage"
    @Volatile private var running = false
    private var inEp: UsbEndpoint? = null
    private var outEp: UsbEndpoint? = null

    fun start() {
        running = true
        Thread { try { loop() } catch (e: Exception) { info = "erreur : ${e.message}" } finally { conn.close() } }.start()
    }
    fun stop() { running = false }

    private fun packet(cmd: Int, data: ByteArray = ByteArray(0)): ByteArray {
        val p = ByteArray(64); val len = data.size + 3
        p[0] = 0xAA.toByte(); p[5] = len.toByte(); p[6] = (len shr 8).toByte(); p[7] = cmd.toByte()
        System.arraycopy(data, 0, p, 8, data.size)
        val c = CRC32(); c.update(p, 5, len)
        for (i in 0..3) p[1 + i] = (c.value shr (8 * i)).toByte()
        return p
    }

    private fun exchange(cmd: Int, data: ByteArray = ByteArray(0)): ByteArray? {
        conn.bulkTransfer(outEp!!, packet(cmd, data), 64, 200)
        val b = ByteArray(64)
        repeat(6) {
            val r = conn.bulkTransfer(inEp!!, b, 64, 200)
            if (r > 0 && (b[0].toInt() and 0xff) == 0xAA && (b[7].toInt() and 0xff) == cmd) return b.copyOf()
        }
        return null
    }

    private fun u16(b: ByteArray, o: Int) = (b[o].toInt() and 0xff) or ((b[o + 1].toInt() and 0xff) shl 8)
    private fun u32(b: ByteArray, o: Int): Long { var v = 0L; for (i in 3 downTo 0) v = (v shl 8) or (b[o + i].toLong() and 0xff); return v }
    private fun i64(b: ByteArray, o: Int): Long { var v = 0L; for (i in 7 downTo 0) v = (v shl 8) or (b[o + i].toLong() and 0xff); return v }
    private fun s24(b: ByteArray, o: Int): Int {
        val v = (b[o].toInt() and 0xff) or ((b[o + 1].toInt() and 0xff) shl 8) or ((b[o + 2].toInt() and 0xff) shl 16)
        return if ((v and 0x800000) != 0) v - 0x1000000 else v
    }

    private fun loop() {
        val itf = (0 until dev.interfaceCount).map { dev.getInterface(it) }.firstOrNull { it.id == 3 }
            ?: run { info = "interface 3 absente"; return }
        for (i in 0 until itf.endpointCount) {
            val e = itf.getEndpoint(i)
            if (e.address == 0x84) inEp = e
            if (e.address == 0x05) outEp = e
        }
        if (inEp == null || outEp == null) { info = "endpoints absents"; return }
        conn.claimInterface(itf, true)

        info = "activation…"
        exchange(0x19, byteArrayOf(0))               // arrêt du flux (le 1er échange peut expirer)
        exchange(0x1A)
        val r = exchange(0x14)                       // taille du fichier de calibration
        val len = if (r != null) u32(r, 8) else 0L
        var n = if (len in 1L..30000L) ((len + 55) / 56).toInt() else 0
        while (n-- > 0 && running) { if (exchange(0x15) == null) break }
        val ok = exchange(0x19, byteArrayOf(1)) != null
        info = if (ok) "flux activé" else "pas de réponse à l’activation"

        val b = ByteArray(64)
        var count = 0; var t0 = System.currentTimeMillis()
        val gBias = FloatArray(3); val aSum = FloatArray(3)
        var calN = 0; var calStart = 0L; var calDone = false; var gIdx = 2
        var lastTs = 0L; var first = true
        val f = Mahony()
        while (running) {
            val rd = conn.bulkTransfer(inEp!!, b, 64, 200)
            val now = System.currentTimeMillis()
            if (now - t0 >= 1000) { rate = count; count = 0; t0 = now }
            if (rd < 0x30 || b[0].toInt() != 1 || b[1].toInt() != 2) continue
            count++
            val ts = i64(b, 4)
            val gd = u32(b, 0x0E); val ad = u32(b, 0x1D)
            if (gd == 0L || ad == 0L) continue
            val gs = u16(b, 0x0C).toFloat() / gd; val ac = u16(b, 0x1B).toFloat() / ad
            val g = floatArrayOf(s24(b, 0x12) * gs, s24(b, 0x15) * gs, s24(b, 0x18) * gs)
            val a = floatArrayOf(s24(b, 0x21) * ac, s24(b, 0x24) * ac, s24(b, 0x27) * ac)

            if (!calDone) {                          // ~0,7 s immobile : biais du gyro + axe vertical
                if (calN == 0) calStart = now
                for (i in 0..2) { gBias[i] += g[i]; aSum[i] += a[i] }
                calN++
                info = "calibrage : restez immobile"
                if (now - calStart >= 700) {
                    for (i in 0..2) gBias[i] /= calN
                    gIdx = (0..2).maxByOrNull { abs(aSum[it]) } ?: 2
                    calDone = true; lastTs = ts
                    info = "suivi actif (axe vertical $gIdx)"
                }
                continue
            }
            val dt = ((ts - lastTs) * 1e-9).toFloat().coerceIn(0f, 0.1f); lastTs = ts
            val k = if (Anchor.gyroDeg) (PI / 180).toFloat() else 1f
            f.update((g[0] - gBias[0]) * k, (g[1] - gBias[1]) * k, (g[2] - gBias[2]) * k, a[0], a[1], a[2], dt)
            val h = (0..2).filter { it != gIdx }
            val v = f.column(h[Anchor.fwdIdx and 1])
            val yaw = Math.toDegrees(atan2(v[1], v[0]).toDouble()).toFloat()
            val pitch = Math.toDegrees(asin(v[2].coerceIn(-1f, 1f)).toDouble()).toFloat()
            Anchor.yaw = if (Anchor.flipYaw) -yaw else yaw
            Anchor.pitch = if (Anchor.flipPitch) -pitch else pitch
            if (first) { Anchor.recenter(); first = false }
        }
    }
}

/** Filtre d'orientation de Mahony (gyro + gravité). */
class Mahony {
    private var q0 = 1f; private var q1 = 0f; private var q2 = 0f; private var q3 = 0f

    fun update(gxIn: Float, gyIn: Float, gzIn: Float, ax0: Float, ay0: Float, az0: Float, dt: Float) {
        var gx = gxIn; var gy = gyIn; var gz = gzIn
        val n = sqrt(ax0 * ax0 + ay0 * ay0 + az0 * az0)
        if (n > 1e-6f) {
            val ax = ax0 / n; val ay = ay0 / n; val az = az0 / n
            val vx = 2f * (q1 * q3 - q0 * q2); val vy = 2f * (q0 * q1 + q2 * q3); val vz = q0 * q0 - q1 * q1 - q2 * q2 + q3 * q3
            gx += KP * (ay * vz - az * vy); gy += KP * (az * vx - ax * vz); gz += KP * (ax * vy - ay * vx)
        }
        val h = 0.5f * dt
        val d0 = (-q1 * gx - q2 * gy - q3 * gz) * h
        val d1 = (q0 * gx + q2 * gz - q3 * gy) * h
        val d2 = (q0 * gy - q1 * gz + q3 * gx) * h
        val d3 = (q0 * gz + q1 * gy - q2 * gx) * h
        q0 += d0; q1 += d1; q2 += d2; q3 += d3
        val m = sqrt(q0 * q0 + q1 * q1 + q2 * q2 + q3 * q3)
        q0 /= m; q1 /= m; q2 /= m; q3 /= m
    }

    /** Colonne k de la matrice sensor→monde (axe k du capteur exprimé dans le monde). */
    fun column(k: Int): FloatArray = when (k) {
        0 -> floatArrayOf(1f - 2f * (q2 * q2 + q3 * q3), 2f * (q1 * q2 + q0 * q3), 2f * (q1 * q3 - q0 * q2))
        1 -> floatArrayOf(2f * (q1 * q2 - q0 * q3), 1f - 2f * (q1 * q1 + q3 * q3), 2f * (q2 * q3 + q0 * q1))
        else -> floatArrayOf(2f * (q1 * q3 + q0 * q2), 2f * (q2 * q3 - q0 * q1), 1f - 2f * (q1 * q1 + q2 * q2))
    }
    companion object { const val KP = 2f }
}
