package com.arscreenanchor.display

import android.app.Activity
import android.app.PendingIntent
import android.content.*
import android.hardware.usb.*
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.view.Display
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private lateinit var dot: View
    private lateinit var status: TextView
    private lateinit var go: Button
    private lateinit var tracker: Tracker
    private var pres: GlassesPresentation? = null
    private var running = false
    private lateinit var diagOut: TextView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun shape(c: Int, r: Int) = GradientDrawable().apply { cornerRadius = dp(r).toFloat(); setColor(c) }
    private fun btn(t: String, bg: Int, f: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; textSize = 16f; setTextColor(Color.WHITE)
        background = shape(bg, 14); setOnClickListener { f() }
    }
    private fun external(): Display? =
        (getSystemService(DISPLAY_SERVICE) as DisplayManager).displays.firstOrNull { it.displayId != Display.DEFAULT_DISPLAY }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        tracker = Tracker(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(0xFF0D1117.toInt()); setPadding(dp(20), dp(48), dp(20), dp(20))
        }
        fun add(v: View, top: Int = 14) = root.addView(v, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(top) })
        fun label(t: String) = TextView(this).apply { text = t; setTextColor(0xFF8B949E.toInt()); textSize = 14f }

        add(TextView(this).apply { text = "AR Screen Anchor"; setTextColor(Color.WHITE); textSize = 24f }, 0)
        dot = View(this); status = label("Lunettes non détectées")
        val st = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        st.addView(dot, LinearLayout.LayoutParams(dp(12), dp(12)).apply { rightMargin = dp(8) }); st.addView(status)
        add(st, 8)

        go = btn("Démarrer la copie", 0xFF4C9AFF.toInt()) { if (running) stop() else askCapture() }
        go.setTextColor(0xFF06101F.toInt()); add(go, 24)

        val row = LinearLayout(this)
        val lock = btn("Mode : Verrouillé", 0xFF21262D.toInt()) {}
        lock.setOnClickListener {
            Anchor.locked = !Anchor.locked; if (!Anchor.locked) Anchor.recenter()
            lock.text = "Mode : " + if (Anchor.locked) "Verrouillé" else "Suivi"
        }
        row.addView(btn("Recentrer", 0xFF21262D.toInt()) { Anchor.recenter() }, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(6) })
        row.addView(lock, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(6) })
        add(row)

        val size = label("Taille de l’écran : ${Anchor.sizePct} %")
        add(size, 24)
        add(SeekBar(this).apply {
            max = 80; progress = Anchor.sizePct - 20
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { Anchor.sizePct = 20 + p; size.text = "Taille de l’écran : ${20 + p} %" }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }, 4)
        add(label("Suivi de tête : capteurs de la tablette (lecture des capteurs USB des lunettes pas encore implémentée)"), 24)
        add(btn("Diagnostic lunettes (USB)", 0xFF21262D.toInt()) { diag() }, 16)
        diagOut = TextView(this).apply { setTextColor(0xFFE6EDF3.toInt()); textSize = 11f; typeface = android.graphics.Typeface.MONOSPACE; setTextIsSelectable(true) }
        add(ScrollView(this).apply { addView(diagOut) }, 8)
        add(btn("Partager le résultat", 0xFF21262D.toInt()) {
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, diagOut.text.toString()), null))
        }, 8)
        setContentView(root)

        (getSystemService(DISPLAY_SERVICE) as DisplayManager).registerDisplayListener(object : DisplayManager.DisplayListener {
            override fun onDisplayAdded(id: Int) = refresh()
            override fun onDisplayRemoved(id: Int) = refresh()
            override fun onDisplayChanged(id: Int) {}
        }, null)
    }

    private fun capture(conn: UsbDeviceConnection, ep: UsbEndpoint, sb: StringBuilder) {
        val buf = ByteArray(ep.maxPacketSize)
        val mn = Array(2) { IntArray(64) { 255 } }; val mx = Array(2) { IntArray(64) }
        val last = Array(2) { ByteArray(64) }; val cnt = IntArray(2)
        val t0 = System.currentTimeMillis(); var beeped = false
        while (true) {
            val t = System.currentTimeMillis() - t0
            if (t > 6000) break
            val ph = if (t < 3000) 0 else 1
            if (ph == 1 && !beeped) { beeped = true; ToneGenerator(AudioManager.STREAM_MUSIC, 100).startTone(ToneGenerator.TONE_PROP_BEEP2, 400) }
            val r = conn.bulkTransfer(ep, buf, buf.size, 100)
            if (r <= 0) continue
            cnt[ph]++
            for (i in 0 until minOf(r, 64)) { val v = buf[i].toInt() and 0xff; if (v < mn[ph][i]) mn[ph][i] = v; if (v > mx[ph][i]) mx[ph][i] = v }
            System.arraycopy(buf, 0, last[ph], 0, minOf(r, 64))
        }
        sb.append("    immobile: ${cnt[0]} paquets, mouvement: ${cnt[1]}\n")
        for (i in 24 until 64) if (mx[0][i] > mn[0][i] || mx[1][i] > mn[1][i] || mx[1][i] > 0)
            sb.append("    [%02d] immo %02x-%02x  mvt %02x-%02x\n".format(i, mn[0][i], mx[0][i], mn[1][i], mx[1][i]))
        for (p in 0..1) sb.append(if (p == 0) "    dernier immo: " else "    dernier mvt: ").append(last[p].joinToString(" ") { "%02x".format(it) }).append("\n")
    }

    private fun diag() {
        val um = getSystemService(USB_SERVICE) as UsbManager
        val sb = StringBuilder("Appareils USB :\n")
        um.deviceList.values.forEach { sb.append("%04x:%04x %s\n".format(it.vendorId, it.productId, it.productName ?: "?")) }
        val dev = Usb.find(this)
        if (dev == null) { diagOut.text = sb.append("Aucune lunette (fabricant 3318) trouvée.").toString(); return }
        if (!um.hasPermission(dev)) {
            val act = "com.arscreenanchor.USB"
            val rc = object : BroadcastReceiver() { override fun onReceive(c: Context?, i: Intent?) { unregisterReceiver(this); diag() } }
            val f = IntentFilter(act)
            if (Build.VERSION.SDK_INT >= 33) registerReceiver(rc, f, Context.RECEIVER_NOT_EXPORTED) else registerReceiver(rc, f)
            um.requestPermission(dev, PendingIntent.getBroadcast(this, 0, Intent(act).setPackage(packageName), PendingIntent.FLAG_MUTABLE))
            diagOut.text = "Autorisez l’accès USB…"; return
        }
        val conn = um.openDevice(dev) ?: run { diagOut.text = "Ouverture impossible"; return }
        diagOut.text = "Lecture en cours (~10 s).\nRestez immobile jusqu’au bip, puis tournez la tête de gauche à droite pendant 3 secondes."
        Thread {
            for (n in 0 until dev.interfaceCount) {
                val itf = dev.getInterface(n)
                sb.append("Interface ${itf.id} classe ${itf.interfaceClass}\n")
                for (e in 0 until itf.endpointCount) {
                    val ep = itf.getEndpoint(e)
                    val dir = if (ep.direction == UsbConstants.USB_DIR_IN) "IN" else "OUT"
                    sb.append("  ep 0x%02x type %d %s taille %d\n".format(ep.address, ep.type, dir, ep.maxPacketSize))
                    if (ep.type == UsbConstants.USB_ENDPOINT_XFER_INT && ep.direction == UsbConstants.USB_DIR_IN) {
                        conn.claimInterface(itf, true)
                        if (ep.address == 0x88) { capture(conn, ep, sb); continue }
                        val buf = ByteArray(ep.maxPacketSize); var cnt = 0
                        val end = System.currentTimeMillis() + 1000
                        while (System.currentTimeMillis() < end) {
                            val r = conn.bulkTransfer(ep, buf, buf.size, 100)
                            if (r > 0) { cnt++; if (cnt <= 2) sb.append("    ").append(buf.take(r).joinToString(" ") { "%02x".format(it) }).append("\n") }
                        }
                        sb.append("    paquets reçus : $cnt\n")
                    }
                }
            }
            conn.close()
            runOnUiThread { diagOut.text = sb.toString() }
        }.start()
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun refresh() {
        val usb = Usb.find(this) != null; val ext = external() != null
        status.text = when { usb -> "Lunettes détectées (USB)"; ext -> "Écran externe détecté"; else -> "Lunettes non détectées" }
        dot.background = shape(if (usb || ext) 0xFF3FB950.toInt() else 0xFFF85149.toInt(), 6)
    }

    private fun askCapture() {
        if (external() == null) { Toast.makeText(this, "Branchez les lunettes (USB-C) d’abord", Toast.LENGTH_LONG).show(); return }
        startActivityForResult((getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager).createScreenCaptureIntent(), 1)
    }

    @Deprecated("simple")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        if (req != 1 || res != RESULT_OK || data == null) return
        CaptureService.onReady = { p -> runOnUiThread { begin(p) } }
        startForegroundService(Intent(this, CaptureService::class.java).putExtra("c", res).putExtra("d", data))
    }

    private fun begin(p: MediaProjection) {
        val d = external() ?: return
        val m = resources.displayMetrics
        Anchor.recenter(); tracker.start()
        pres = GlassesPresentation(this, d, p, m.widthPixels, m.heightPixels, m.densityDpi).also { it.show() }
        running = true; go.text = "Arrêter la copie"
    }

    private fun stop() {
        pres?.dismiss(); pres = null; tracker.stop()
        stopService(Intent(this, CaptureService::class.java))
        running = false; go.text = "Démarrer la copie"
    }
}
