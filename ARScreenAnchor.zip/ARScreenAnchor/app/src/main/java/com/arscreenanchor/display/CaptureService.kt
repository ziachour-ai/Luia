package com.arscreenanchor.display

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper

/** Service de premier plan, obligatoire pour la capture d'écran (MediaProjection). */
class CaptureService : Service() {
    companion object {
        var projection: MediaProjection? = null
        var onReady: ((MediaProjection) -> Unit)? = null
    }
    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("cap", "Capture", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "cap").setContentTitle("AR Screen Anchor")
            .setContentText("Copie d’écran active").setSmallIcon(android.R.drawable.ic_menu_view).build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        val data = i?.getParcelableExtra<Intent>("d")
        val code = i?.getIntExtra("c", 0) ?: 0
        if (data != null) {
            val p = getSystemService(MediaProjectionManager::class.java).getMediaProjection(code, data)
            p.registerCallback(object : MediaProjection.Callback() {}, Handler(Looper.getMainLooper())) // requis Android 14
            projection = p
            onReady?.invoke(p)
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() { projection?.stop(); projection = null }
}
